const { connectToDatabase, closeDatabase } = require("../src/db");

const items = [
  { title: "Wooden Chair", description: "Solid wooden chair in good condition.", category: "Furniture", location: "Tashkent", condition: "Good" },
  { title: "Desk Lamp", description: "Working desk lamp.", category: "Electronics", location: "Tashkent", condition: "Good" },
  { title: "Coffee Table", description: "Small coffee table.", category: "Furniture", location: "Samarkand", condition: "Used" },
  { title: "Bookshelf", description: "Five-shelf wooden bookcase.", category: "Furniture", location: "Tashkent", condition: "Good" },
  { title: "Kitchen Plates", description: "Set of reusable plates.", category: "Kitchen", location: "Tashkent", condition: "Good" },
  { title: "Electric Kettle", description: "Working electric kettle.", category: "Kitchen", location: "Bukhara", condition: "Good" },
  { title: "Backpack", description: "Everyday backpack.", category: "Clothing", location: "Tashkent", condition: "Used" },
  { title: "Winter Jacket", description: "Warm winter jacket.", category: "Clothing", location: "Samarkand", condition: "Good" },
  { title: "Monitor Stand", description: "Adjustable monitor stand.", category: "Electronics", location: "Tashkent", condition: "Good" },
  { title: "Floor Rug", description: "Medium size rug.", category: "Home", location: "Bukhara", condition: "Used" },
  { title: "Plant Pot", description: "Ceramic plant pot.", category: "Home", location: "Tashkent", condition: "Good" },
  { title: "Camping Tent", description: "Two-person camping tent.", category: "Outdoor", location: "Samarkand", condition: "Used" },
  { title: "Children Books", description: "Collection of children's books.", category: "Books", location: "Tashkent", condition: "Good" },
  { title: "Office Keyboard", description: "USB keyboard.", category: "Electronics", location: "Tashkent", condition: "Good" },
  { title: "Storage Box", description: "Plastic storage box.", category: "Home", location: "Bukhara", condition: "Good" },
  { title: "Bicycle Helmet", description: "Adult bicycle helmet.", category: "Outdoor", location: "Tashkent", condition: "Good" }
].map(item => ({ ...item, createdAt: new Date() }));

async function seed() {
  const db = await connectToDatabase();
  await db.collection("items").deleteMany({});
  const result = await db.collection("items").insertMany(items);
  console.log("inserted_items:", result.insertedCount);
  console.log("inserted_ids:", Object.values(result.insertedIds).map(String));
  await closeDatabase();
}

seed().catch(async (error) => {
  console.error(error);
  await closeDatabase();
  process.exit(1);
});
