# SecondChance User Story Template

## User Story

**As a** [type of user]

**I want** [goal]

**So that** [benefit]

### Acceptance Criteria

- [ ] Given [context], when [action], then [expected result].
- [ ] Given [context], when [action], then [expected result].
- [ ] Error cases are handled with an appropriate HTTP status.

### Notes

Add implementation, API, data, and testing notes here.
