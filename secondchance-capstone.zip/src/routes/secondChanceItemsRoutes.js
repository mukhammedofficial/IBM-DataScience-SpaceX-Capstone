const express = require("express");
const multer = require("multer");
const path = require("path");
const { ObjectId } = require("mongodb");
const { connectToDatabase } = require("../db");

const router = express.Router();

const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    const safeName = `${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    cb(null, safeName);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }
});

// GET /api/secondchance/items
router.get("/", async (req, res, next) => {
  try {
    const db = await connectToDatabase();
    const items = await db.collection("items").find({}).sort({ createdAt: -1 }).toArray();
    res.json(items);
  } catch (error) {
    next(error);
  }
});

// GET /api/secondchance/items/:id
router.get("/:id", async (req, res, next) => {
  try {
    const db = await connectToDatabase();
    const item = await db.collection("items").findOne({
      _id: new ObjectId(req.params.id)
    });

    if (!item) {
      return res.status(404).json({ error: "Item not found" });
    }

    res.json(item);
  } catch (error) {
    next(error);
  }
});

// POST /api/secondchance/items
router.post("/", upload.single("file"), async (req, res, next) => {
  try {
    const db = await connectToDatabase();

    const item = {
      title: req.body.title,
      description: req.body.description || "",
      category: req.body.category || "Other",
      location: req.body.location || "",
      condition: req.body.condition || "Good",
      ownerEmail: req.body.ownerEmail || "",
      image: req.file ? `/uploads/${req.file.filename}` : null,
      createdAt: new Date()
    };

    if (!item.title) {
      return res.status(400).json({ error: "title is required" });
    }

    const result = await db.collection("items").insertOne(item);
    res.status(201).json({ ...item, _id: result.insertedId });
  } catch (error) {
    next(error);
  }
});

// DELETE /api/secondchance/items/:id
router.delete("/:id", async (req, res, next) => {
  try {
    const db = await connectToDatabase();
    const result = await db.collection("items").deleteOne({
      _id: new ObjectId(req.params.id)
    });

    if (result.deletedCount === 0) {
      return res.status(404).json({ error: "Item not found" });
    }

    res.json({ message: "Item deleted successfully" });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
