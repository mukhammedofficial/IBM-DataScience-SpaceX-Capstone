const express = require("express");
const { connectToDatabase } = require("../db");

const router = express.Router();

async function handle(req, res, next) {
  try {
    const db = await connectToDatabase();
    const { category, q, location } = req.query;

    const filter = {};

    // Required capstone category filter.
    if (category) {
      filter.category = category;
    }

    if (location) {
      filter.location = { $regex: location, $options: "i" };
    }

    if (q) {
      filter.$or = [
        { title: { $regex: q, $options: "i" } },
        { description: { $regex: q, $options: "i" } }
      ];
    }

    const items = await db.collection("items").find(filter).toArray();
    res.json(items);
  } catch (error) {
    next(error);
  }
}

router.get("/", handle);
router.handle = handle;

module.exports = router;
