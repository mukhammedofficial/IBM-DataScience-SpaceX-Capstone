const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { ObjectId } = require("mongodb");
const { connectToDatabase } = require("../db");

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "development_secret";

function publicUser(user) {
  const { passwordHash, ...safeUser } = user;
  return safeUser;
}

// POST /api/secondchance/auth/register
router.post("/register", async (req, res, next) => {
  try {
    const db = await connectToDatabase();
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: "name, email and password are required" });
    }

    const existing = await db.collection("users").findOne({ email });
    if (existing) {
      return res.status(409).json({ error: "User already exists" });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const user = {
      name,
      email,
      passwordHash,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const result = await db.collection("users").insertOne(user);

    res.status(201).json({
      message: "User registered successfully",
      user: publicUser({ ...user, _id: result.insertedId })
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/secondchance/auth/login
router.post("/login", async (req, res, next) => {
  try {
    const db = await connectToDatabase();
    const { email, password } = req.body;

    const user = await db.collection("users").findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const token = jwt.sign(
      { userId: user._id.toString(), email: user.email },
      JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.json({
      message: "Login successful",
      token,
      user: publicUser(user)
    });
  } catch (error) {
    next(error);
  }
});

// PUT /api/secondchance/auth/users/:id
router.put("/users/:id", async (req, res, next) => {
  try {
    const db = await connectToDatabase();
    const updates = {};

    if (req.body.name) updates.name = req.body.name;
    if (req.body.email) updates.email = req.body.email;
    updates.updatedAt = new Date();

    const result = await db.collection("users").findOneAndUpdate(
      { _id: new ObjectId(req.params.id) },
      { $set: updates },
      { returnDocument: "after" }
    );

    if (!result) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({
      message: "User updated successfully",
      user: publicUser(result)
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
