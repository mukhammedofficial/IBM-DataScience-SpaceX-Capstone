const { MongoClient } = require("mongodb");
require("dotenv").config();

const uri = process.env.MONGODB_URI || "mongodb://localhost:27017";
const dbName = process.env.MONGODB_DB || "secondchance";

const client = new MongoClient(uri);

let db;

async function connectToDatabase() {
  if (!db) {
    await client.connect();
    db = client.db(dbName);
  }
  return db;
}

async function closeDatabase() {
  await client.close();
  db = null;
}

module.exports = { client, connectToDatabase, closeDatabase };
