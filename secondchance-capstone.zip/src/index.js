const natural = require("natural");
const app = require("./app");
const { connectToDatabase } = require("./db");
require("dotenv").config();

const PORT = process.env.PORT || 3000;

async function startServer() {
  await connectToDatabase();

  app.listen(PORT, () => {
    console.log(`SecondChance server running on port ${PORT}`);
    console.log(`Natural version loaded: ${natural.version || "available"}`);
  });
}

startServer().catch((error) => {
  console.error("Failed to start SecondChance:", error);
  process.exit(1);
});
