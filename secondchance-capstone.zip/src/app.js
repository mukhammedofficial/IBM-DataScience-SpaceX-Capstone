const express = require("express");
const cors = require("cors");

const secondChanceItemsRoutes = require("./routes/secondChanceItemsRoutes");
const searchRoutes = require("./routes/searchRoutes");
const authRoutes = require("./routes/authRoutes");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static("public"));

app.get("/health", (req, res) => {
  res.json({ status: "ok", service: "SecondChance" });
});

app.use("/api/secondchance/items", secondChanceItemsRoutes);
app.use("/api/secondchance/search", searchRoutes);
app.use("/api/secondchance/auth", authRoutes);

app.get("/api/secondchance/search", (req, res, next) => {
  return searchRoutes.handle(req, res, next);
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

module.exports = app;
