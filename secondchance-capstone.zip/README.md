# SecondChance

SecondChance is a Node.js + Express REST API for a fictitious platform that connects people giving away household items with people who want to recycle and reuse free items.

## Technology

- Node.js
- Express
- MongoDB
- JWT authentication
- bcrypt password hashing
- Multer file upload
- Natural NLP package
- Docker
- GitHub Actions CI/CD

## Run locally

```bash
npm install
cp .env.example .env
npm start
```

The application listens on `http://localhost:3000`.

## Main endpoints

- `GET /api/secondchance/items`
- `GET /api/secondchance/items/:id`
- `POST /api/secondchance/items`
- `DELETE /api/secondchance/items/:id`
- `GET /api/secondchance/search`
- `POST /api/secondchance/auth/register`
- `POST /api/secondchance/auth/login`
- `PUT /api/secondchance/auth/users/:id`

## Capstone evidence

See the `docs/` directory for the required cURL evidence and MongoDB import output.

